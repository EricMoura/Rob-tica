import socket
import time

HOST = '192.168.0.25'  # Endereço IP do servidor
PORT = 3505 # Porta utilizada pelo servidor


def cria_socket():
    global sock
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Vincula o socket ao endereço IP e porta
    if not sock:
        sock.bind((HOST, PORT))
    else:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((HOST, PORT))

    return sock

def fecha_socket():
    sock.close()


    