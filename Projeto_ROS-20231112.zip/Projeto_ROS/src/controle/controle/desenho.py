#!/usr/bin/env python3
import rclpy
import time
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from controle.socket_con import cria_socket, fecha_socket

class DrawGraphic(Node):

    def __init__(self):

        super().__init__("draw_graphic")
        self.sock = cria_socket()
        
        self.cmd_vel_pub_ = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        self.pose_subscriber = self.create_subscription(
            Pose, "/turtle1/pose", self.pose_callback, 10
        )



        self.timer_ = self.create_timer(0.4, self.send_velocity_command)
        self.get_logger().info("Draw node started")
        
    def send_velocity_command(self):
        dict = {'a':'Voltar','d':'Direita','f':'Frente','e':'Esquerda'}
        direcao, addr = self.sock.recvfrom(1024)

        try:
            direcao = direcao.decode('utf-8')
        except:
            return
        
        msg = Twist()
        
        print('Comando novo:',direcao[0].translate(dict),', Distância percorrida: ', direcao[1:],'metros')

        try:
            if direcao[0] == 'a':
                msg.linear.x = -0.1
                msg.angular.z = 0.0

                self.cmd_vel_pub_.publish(msg)

            if direcao[0]=='f':
                msg.linear.x = 0.2
                msg.angular.z = 0.0

                self.cmd_vel_pub_.publish(msg)
                
            if direcao[0] == 'e':
                msg.linear.x = 0.0
                msg.angular.z = 0.8

                self.cmd_vel_pub_.publish(msg)

            if direcao[0] == 'd':
                msg.linear.x = 0.0
                msg.angular.z = -0.8

                self.cmd_vel_pub_.publish(msg)

        except:
            pass

    def pose_callback(self, msg:Pose):
        pass
        #self.get_logger().info("(" + str(msg.x) + ", " + str(msg.y) + ")")

def main(args=None):
    rclpy.init(args=args)
    node = DrawGraphic()
    rclpy.spin(node)
    rclpy.shutdown()